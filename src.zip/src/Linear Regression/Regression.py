import pandas as pd
import numpy as np
df=pd.read_excel("slr12.xls")
des=df.describe()
'''
mean_=df.mean(0)
mean_x=mean_[0]
mean_y=mean_[1]
print(mean_x,mean_y)
'''

X_=des.loc['mean']['X']
Y_=des.loc['mean']['Y']
std_x=des.loc['std']['X']
std_y=des.loc['std']['Y']
x_X_=df['X']-X_
y_Y_=df['Y']-Y_
x_X_y_Y_=(x_X_)*(y_Y_)
sum_x_X_y_Y_=x_X_y_Y_.sum(0)
sum_square_x_X_=(x_X_*x_X_).sum(0)
sum_square_y_Y_=(y_Y_*y_Y_).sum(0)

r=(sum_x_X_y_Y_)/pow((sum_square_x_X_)*(sum_square_y_Y_),1/2)
print(r)
b=r*(std_y/std_x)

a=Y_ - b * X_
print(a)
x=int(input("enter value of x:"))
print("y value: ")
print(a + b * x)